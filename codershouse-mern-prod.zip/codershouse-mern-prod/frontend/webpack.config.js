module.exports = {
    devServer: {
        disableHostCheck: true,
        historyApiFallback: true,
    },
};
